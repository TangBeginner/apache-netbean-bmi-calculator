/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.cal;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author HP
 */
public class bmi_cal extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/test/calculation.wsdl")
    private Calculation_Service service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            try {
                out.println("<!DOCTYPE html><html> <head> <title>PERSONAL HEALTH & FITNESS CALCULATOR</title> <meta charset='UTF-8'> <meta name='viewport' content='width=device-width, initial-scale=1.0'> <style>body{padding: 15px; font-family: Arial, Helvetica, sans-serif; min-width: 700px;color: black;background: url(https://images.pexels.com/photos/616401/pexels-photo-616401.jpeg?cs=srgb&dl=pexels-lukas-616401.jpg&fm=jpg); background-size: cover;background-repeat: repeat-y;}.container{width: 500px; padding: 30px; border: 1px solid #ccc;color:black; border-radius: 25px; background: #f2f2f2; box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px; margin-bottom: 70px;}a{margin-top: 5px; padding: 12px; border-radius: 4px; border: 1px solid #ccc;border-radius: 20px; background: white;}a:hover{background: yellow;} td{padding: 15px;}tr:nth-child(even){background-color:#d9d9d9;}table{border-collapse: collapse;}</style> </head> <body> ");
                
                /* TODO output your page here. You may use following sample code. */
                String name = request.getParameter("name");
                String ic = request.getParameter("ic");
                String gender = request.getParameter("gender");
                double weight = Double.parseDouble(request.getParameter("weight"));
                double height = Double.parseDouble(request.getParameter("height"));
                
                out.println("<center> <div style='background-color:rgba(242, 242, 242,0.6); width: 50%;'> <h1>PERSONAL HEALTH & FITNESS CALCULATOR</h1> <p style='padding-top: 10px; padding-bottom: 10px;'>- - - Your Body Mass Index (BMI) Result - - -</p></div><div class='container'> <table> <tr> <td style='width: 100px;'>Name: </td><td>" + name + "</td></tr><tr> <td>I/C: </td><td>" + ic + "</td></tr><tr> <td>Age: </td><td>" + calculateAge(gender, ic) + "</td></tr><tr> <td>Gender: </td><td>" + gender + "</td></tr><tr> <td>Weight: </td><td>" + weight + " kg </td></tr><tr> <td>Height: </td><td>" + height + " cm </td></tr><tr> <td>BMI: </td><td>" + calculateBMI(weight, height) + " </td></tr></table> </div><a href='index.html'/>Return</a> </center>");
            } catch (Exception e) {
                out.println("<center><div style='background-color:rgba(242, 242, 242,0.6); width: 60%; margin-top:10rem; margin-bottom: 5rem;'><h1>An error happened as a result of: " + e.getMessage() + "</h1></div> <a href='index.html'/>Return</a> </center>");
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private int calculateAge(java.lang.String gender, java.lang.String ic) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.cal.Calculation port = service.getCalculationPort();
        return port.calculateAge(gender, ic);
    }

    private String calculateBMI(double weight, double height) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.cal.Calculation port = service.getCalculationPort();
        return port.calculateBMI(weight, height);
    }
    
}
