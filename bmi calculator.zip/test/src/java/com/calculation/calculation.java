/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package com.calculation;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.time.LocalDate;
import java.time.Period;
import javax.xml.soap.SOAPFault;
import javax.xml.ws.soap.SOAPFaultException;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;

/**
 *
 * @author HP
 */
@WebService(serviceName = "calculation")
public class calculation {

    private SOAPFault createSOAPFault(String errorMessage) {
        try {
            SOAPFault soapFault = SOAPFactory.newInstance().createFault();
            soapFault.setFaultString(errorMessage);
            return soapFault;
        } catch (SOAPException e) {
            throw new RuntimeException("Failed to create SOAP fault.", e);
        }
    }
    
    // -------------------------------------------------------------------------------------------------------
    /**
     * Web service operation
     *
     * @param ic input value of identification number
     * @param gender input value of gender ("female" or "male")
     * @return calculate age based on identification number
     */
    @WebMethod(operationName = "calculateAge")
    // declare ic as String to ensure that leading zeros are retained when processing the IC number
    public int calculateAge(@WebParam(name = "gender") String gender, @WebParam(name = "ic") String ic) {
        try {
            if (gender == null || gender.isEmpty()) {
                throw new SOAPFaultException(createSOAPFault("Gender is required."));
            }

            if (ic == null || ic.isEmpty()) {
                throw new SOAPFaultException(createSOAPFault("Identification number is required."));
            }

            // Validate gender format
            if (!isValidGender(gender)) {
                throw new SOAPFaultException(
                        createSOAPFault("Invalid gender: " + gender + ". Please enter 'male' or 'female'."));
            }

            // Check if the IC number is valid
            if (!isValidIC(ic, gender)) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid Identification number format: " + ic + ". Please check the ic format."));
            }

            int age = determineAge(ic);
            return age;
        } catch (SOAPFaultException e) {
            throw e; // Re-throw SOAPFaultException
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            if (e.getCause() != null) {
                errorMessage = e.getCause().getMessage();
            }
            throw new SOAPFaultException(
                    createSOAPFault("An error occurred while processing the request. Details: " + errorMessage));
        }
    }

    private boolean isValidGender(String gender) {
        String inputGender = gender.toLowerCase();
        return inputGender.equalsIgnoreCase("female") || inputGender.equalsIgnoreCase("male");
    }

    private boolean isValidIC(String icNumber, String gender) {
        // Check IC length
        if (icNumber.length() != 12) {
            return false;
        }

        // Check if all characters are numeric,[0-9]+ means numeric characters between [0-9] should occur one or more times
        if (!icNumber.matches("[0-9]+")) {
            return false;
        }

        // extract the substring index 11
        int genderDigit = Integer.parseInt(icNumber.substring(11, 12));

        // Validate gender
        if (genderDigit % 2 == 0 && gender.equals("female")) {
            return true; // return true when even number and gender is female
        } else {
            return genderDigit % 2 != 0 && gender.equals("male");
            // return true when odd number and gender is male
            // otherwise, return false for other combinations
        }

    }

    private int determineAge(String icNumber) {
        // Extract the birthdate from the identification number
        LocalDate birthdate = extractBirthdate(icNumber);

        // Calculate the age based on the birthdate
        LocalDate currentDate = LocalDate.now();
        int age = Period.between(birthdate, currentDate).getYears();

        return age;
    }

    private LocalDate extractBirthdate(String icNumber) {
        // extract the substring start from index 0 to index 1
        String yearStr = icNumber.substring(0, 2);
        int year = Integer.parseInt(yearStr);
        int currentYear = LocalDate.now().getYear();
        int century = (currentYear / 100) * 100;

        if (year > currentYear % 100) {
            // Assuming the IC number belongs to a person born in the 1900s
            year += century - 100;
        } else {
            // Assuming the IC number belongs to a person born in the 2000s
            year += century;
        }

        // extract the substring start from index 2 to index 3
        String monthStr = icNumber.substring(2, 4);
        int month = Integer.parseInt(monthStr);

        // extract the substring start from index 4 to index 5
        String dayStr = icNumber.substring(4, 6);
        int day = Integer.parseInt(dayStr);

        return LocalDate.of(year, month, day);
    }
    
    // -------------------------------------------------------------------------------------------------------
    /**
     * Web service operation
     *
     * @param weight
     * @param height
     * @return
     */
    @WebMethod(operationName = "calculateBMI")
    public String calculateBMI(@WebParam(name = "weight") double weight, @WebParam(name = "height") double height) {
        try {

            if (weight <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid weight: " + weight + " , weight(kg) must be positive number."));
            }
            
            if (height <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid height: " + height + " , height(cm) must be positive number."));
            }

            height = height / 100;
            double result = weight / (height * height);
            String output = String.format("%.2f", result);
            double bmi = Double.parseDouble(output);
            
            if(bmi < 18.5){
                return "(Underweight) You are below a healthy weight. Your BMI is " + bmi + " kg/m<sup>2</sup>.<br/>You may have inadequate nutrition.<br/>";
            }
            else if(bmi >= 18.5 && bmi <= 24.9){
                return "(Healthy) Congratulation, you have a balanced weight for your height. Your BMI is " + bmi + " kg/m<sup>2</sup>.<br/>Continue to maintain!<br/>";
            }
            else if(bmi >= 25.0 && bmi <=29.9){
                return "(Overweight) You have excess weight. Your BMI is " + bmi + " kg/m<sup>2</sup>.<br/>This may increase the risk of developing various health conditions.<br/>";
            }
            else{
                return "(Obese) You BMI is " + bmi + " kg/m<sup>2</sup>, placing you at an increased risk of obesity-related health problems.<br/>";
            }

        } catch (SOAPFaultException e) {
            throw e; // Re-throw SOAPFaultException
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            if (e.getCause() != null) {
                errorMessage = e.getCause().getMessage();
            }
            throw new SOAPFaultException(
                    createSOAPFault("An error occurred while processing the request. Details: " + errorMessage));
        }
    }

    // -------------------------------------------------------------------------------------------------------
    /**
     * Web service operation
     *
     * @param weight
     * @param height
     * @param age
     * @param gender
     * @return
     */
    @WebMethod(operationName = "calculateBodyFat")
    public String calculateBodyFat(
            @WebParam(name = "weight") double weight,
            @WebParam(name = "height") double height,
            @WebParam(name = "age") int age,
            @WebParam(name = "gender") String gender) {

        try {
            
            if (weight <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid weight: " + weight + " , weight(kg) must be positive number."));
            }
            
            if (height <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid height: " + height + " , height(cm) must be positive number."));
            }
            
            if (age <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid age: " + age + " , age must be positive number."));
            }
            
            height = height / 100;
            double bmi = weight / (height * height);
            double bodyFatPercentage = 0.0;

            // Calculate body fat percentage based on BMI, age, and gender
            if (gender.equalsIgnoreCase("female")) {
                bodyFatPercentage = (1.20 * bmi) + (0.23 * age) - 5.4;
            } else if (gender.equalsIgnoreCase("male")) {
                bodyFatPercentage = (1.20 * bmi) + (0.23 * age) - 16.2;
            }
            
            double result = bodyFatPercentage;
            String output = String.format("%.2f", result);
            double bodyFat = Double.parseDouble(output);
            
            //The American Council on Exercise Body Fat Categorization
            switch(gender){
                case "female":
                    if(bodyFat < 10){
                        return "(Too Low) Your body fat percentage is " + bodyFat + " %.<br/>Warning, you are below the essential fat level. This could result in nutritional deficits and a weakened immune system.";
                    }
                    else if(bodyFat >= 10 && bodyFat <= 13){
                        return "(Essential Fat) Your body fat percentage is " + bodyFat + " %.<br/>You are at the essential fat level, which is the minimal amount of fat required for normal physiological functioning.";
                    }
                    else if(bodyFat>=14 && bodyFat <=20){
                        return "(Athletes) Your body fat percentage is " + bodyFat + " %.<br/>You have low body fat percentages like athletes, it may be due to your high levels of physical activity and muscle mass.";
                    }
                    else if(bodyFat>=21 && bodyFat <=24){
                        return "(Fitness) Your body fat percentage is " + bodyFat + " %.<br/>This range is commonly associated with individuals who are in good physical shape and maintain a regular exercise routine.";
                    }
                    else if(bodyFat>=25 && bodyFat<=31){
                        return "(Average) Your body fat percentage is " + bodyFat + " %.<br/>The average body fat percentage for most adults falls within this range.";
                    }
                    else if(bodyFat>=32){
                        return "(Obese) Your body fat percentage is " + bodyFat + " %.<br/>This range is associated with an increased risk of various health issues";
                    }
                    break;
                    
                case "male":
                    if(bodyFat < 2){
                        return "(Too Low) Your body fat percentage is " + bodyFat + " %.<br/>Warning, you are below the essential fat level. This could result in nutritional deficits and a weakened immune system.";
                    }
                    else if(bodyFat >= 2 && bodyFat <= 5){
                        return "(Essential Fat) Your body fat percentage is " + bodyFat + " %.<br/>You are at the essential fat level, which is the minimal amount of fat required for normal physiological functioning.";
                    }
                    else if(bodyFat>=6 && bodyFat <=13){
                        return "(Athletes) Your body fat percentage is " + bodyFat + " %.<br/>You have low body fat percentages like athletes, it may be due to your high levels of physical activity and muscle mass.";
                    }
                    else if(bodyFat>=14 && bodyFat <=17){
                        return "(Fitness) Your body fat percentage is " + bodyFat + " %.<br/>This range is commonly associated with individuals who are in good physical shape and maintain a regular exercise routine.";
                    }
                    else if(bodyFat>=18 && bodyFat<=24){
                        return "(Average) Your body fat percentage is " + bodyFat + " %.<br/>The average body fat percentage for most adults falls within this range.";
                    }
                    else if(bodyFat>=25){
                        return "(Obese) Your body fat percentage is " + bodyFat + " %.<br/>This range is associated with an increased risk of various health issues";
                    }  
                    break;
                    
                default:
                    throw new SOAPFaultException(createSOAPFault("Invalid gender: " + gender + " . Please choose 'male' or 'female'."));
            }
            
            return null;

        } catch (SOAPFaultException e) {
            throw e; // Re-throw SOAPFaultException
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            if (e.getCause() != null) {
                errorMessage = e.getCause().getMessage();
            }
            throw new SOAPFaultException(
                    createSOAPFault("An error occurred while processing the request. Details: " + errorMessage));
        }

    }

    // -------------------------------------------------------------------------------------------------------
    /**
     * Web service operation
     *
     * @param weight
     * @param height
     * @param activityLevel
     * @param age
     * @param gender
     * @return
     */
    @WebMethod(operationName = "calculateCalorieBurnRate")
    public String calculateCalorieBurnRate(
            @WebParam(name = "weight") double weight,
            @WebParam(name = "height") double height,
            @WebParam(name = "age") int age,
            @WebParam(name = "gender") String gender,
            @WebParam(name = "activityLevel") String activityLevel) {

        if (!isValidGender(gender)) {
            throw new SOAPFaultException(createSOAPFault("Invalid gender. Please choose 'male' or 'female'."));
        }

        if (weight <= 0) {
            throw new SOAPFaultException(createSOAPFault(
                    "Invalid weight: " + weight + " , weight(kg) must be positive number."));
        }

        if (height <= 0) {
            throw new SOAPFaultException(createSOAPFault(
                    "Invalid height: " + height + " , height(cm) must be positive number."));
        }

        if (age <= 0) {
            throw new SOAPFaultException(createSOAPFault(
                    "Invalid age: " + age + " , age must be positive number."));
        }

        double bmr = 0.0;
        double calorieBurnRate = 0.0;

        // Calculate Basal Metabolic Rate (BMR) based on weight, height, age, and gender
        if (gender.equalsIgnoreCase("male")) {
            bmr = 66 + (6.2 * weight) + (12.7 * height) - (6.76 * age);
        } else if (gender.equalsIgnoreCase("female")) {
            bmr = 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        }

        // Calculate calorie burn rate based on BMR and activity level
        switch (activityLevel.toUpperCase()) {
            case "A":
                calorieBurnRate = bmr * 1.2;
                String output = String.format("%.2f", calorieBurnRate);
                return "Your estimated calorie burn rate is " + output + " kcals calories per day. This corresponds to a sedentary lifestyle with little to no exercise.";
            case "B":
                calorieBurnRate = bmr * 1.375;
                output = String.format("%.2f", calorieBurnRate);
                return "Your estimated calorie burn rate is " + output + " kcals calories per day. This corresponds to a lightly active lifestyle with light exercise or sports 1-3 days a week.";
            case "C":
                calorieBurnRate = bmr * 1.55;
                output = String.format("%.2f", calorieBurnRate);
                return "Your estimated calorie burn rate is " + output + " kcals calories per day. This corresponds to a moderately active lifestyle with moderate exercise or sports 3-5 days a week.";
            case "D":
                calorieBurnRate = bmr * 1.725;
                output = String.format("%.2f", calorieBurnRate);
                return "Your estimated calorie burn rate is " + output + " kcals calories per day. This corresponds to a very active lifestyle with hard exercise or sports 6-7 days a week.";
            case "E":
                calorieBurnRate = bmr * 1.9;
                output = String.format("%.2f", calorieBurnRate);
                return "Your estimated calorie burn rate is " + output + " kcals calories per day. This corresponds to an extremely active lifestyle with very hard exercise or a physically demanding job, and regular training.";
            default:
                throw new SOAPFaultException(
                        createSOAPFault("Invalid activity level provided: " + activityLevel + " . Please choose from options A, B, C, D, or E."));
        } 
    }

    // -------------------------------------------------------------------------------------------------------
    /**
     * @param gender male or female
     * @param age Number of years
     * @param height height in cm
     * @param weight weight in kg
     * @param activityLevel has options from A to E
     * @return shows range of calories for losing weight, maintaining weight and
     * gaining weight
     */
    @WebMethod(operationName = "calculateCalorieIntake")
    public String calculateCalorieIntake(
            @WebParam(name = "gender") String gender,
            @WebParam(name = "age") int age,
            @WebParam(name = "height") double height,
            @WebParam(name = "weight") double weight,
            @WebParam(name = "activityLevel") String activityLevel) {

        try {

            if (weight <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid weight: " + weight + " , weight(kg) must be positive number."));
            }

            if (height <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid height: " + height + " , height(cm) must be positive number."));
            }

            if (age <= 0) {
                throw new SOAPFaultException(createSOAPFault(
                        "Invalid age: " + age + " , age must be positive number."));
            }

            // Validate activity level
            if (!isValidActivityLevel(activityLevel)) {
                throw new SOAPFaultException(
                        createSOAPFault(
                                "Invalid activity level: " + activityLevel + " . Please choose from options A, B, C, D, or E."));
            }

            double calorieIntake;

            switch (gender) {
                case "male":
                    calorieIntake = calculateMaleCalorieIntake(age, height, weight, activityLevel);
                    break;
                case "female":
                    calorieIntake = calculateFemaleCalorieIntake(age, height, weight, activityLevel);
                    break;
                default:
                    throw new SOAPFaultException(createSOAPFault("Invalid gender: " + gender + " . Please choose 'male' or 'female'."));
            }

            return formatCalorieIntakeRange(gender, calorieIntake, height, weight);

        } catch (SOAPFaultException e) {
            throw e; // Re-throw SOAPFaultException
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            if (e.getCause() != null) {
                errorMessage = e.getCause().getMessage();
            }
            throw new SOAPFaultException(
                    createSOAPFault("An error occurred while processing the request. Details: " + errorMessage));
        }
    }
    
    // Validate activity level
    private boolean isValidActivityLevel(String activityLevel) {
        return activityLevel.toUpperCase().matches("[A-E]");
    }
    
    private double calculateMaleCalorieIntake(int age, double height, double weight, String activityLevel) {
        // Basal Metabolic Rate (bmr) is the amount of energy (in calories) your body
        // needs to function after resting for 24 hours
        // Harris-Benedict equation
        double bmr = 66.5 + (13.75 * weight) + (5.003 * height) - (6.75 * age);
        return calculateCalorieIntake(bmr, activityLevel);
    }

    private double calculateFemaleCalorieIntake(int age, double height, double weight, String activityLevel) {
        double bmr = 655.1 + (9.563 * weight) + (1.850 * height) - (4.676 * age);
            return calculateCalorieIntake(bmr, activityLevel);
    }
    
    private double calculateCalorieIntake(double bmr, String activityLevel) {
        double calorieMultiplier;

        switch (activityLevel.toUpperCase()) {
            case "A":
                calorieMultiplier = 1.2;
                break;
            case "B":
                calorieMultiplier = 1.375;
                break;
            case "C":
                calorieMultiplier = 1.55;
                break;
            case "D":
                calorieMultiplier = 1.725;
                break;
            case "E":
                calorieMultiplier = 1.9;
                break;
            default:
                calorieMultiplier = 0;
                break;
        }

        return bmr * calorieMultiplier;
    }

    private String formatCalorieIntakeRange(String gender, double calorieIntake, double height, double weight) {
        double loseWeightMin;
        if (gender.equals("male")) {
            // calorie intake should not fall below 1,200 a day in women or 1,500 a day in
            // men
            loseWeightMin = Math.max(calorieIntake - 300, 1500);
        } else {
            loseWeightMin = Math.max(calorieIntake - 300, 1200);
        }

        double loseWeightMax;
        if (gender.equals("male")) {
            loseWeightMax = Math.max(calorieIntake - 150, 1600);
        } else {
            loseWeightMax = Math.max(calorieIntake - 150, 1300);
        }

        double maintainWeightMin;
        if (gender.equals("male")) {
            maintainWeightMin = Math.max(calorieIntake - 100, 1500);
        } else {
            maintainWeightMin = Math.max(calorieIntake - 100, 1200);
        }

        double maintainWeightMax = calorieIntake + 100;
        double gainWeightMin = calorieIntake + 500;
        double gainWeightMax = calorieIntake + 800;

        // convert height in cm to m
        double mHeight = height / 100.0; // use 100.0 for division to obtain decimal value
        // calculate bmi = kg/m^2
        double bmi = weight / (mHeight * mHeight);

        if (bmi < 18.5) {
            /*
                * StringBuilder is used to create mutable which allowing you to modify the
                * contents of the string
                * without creating new string objects at each modification
             */
            StringBuilder result = new StringBuilder();

            result.append(
                    "Your BMI is less than 18.5, which falls within the underweight range. It is not recommended for you to lose weight.<br/><br/>");

            result.append("You should gain more weight: ")
                    .append(String.format("%.0f", gainWeightMin))
                    .append(" to ")
                    .append(String.format("%.0f", gainWeightMax))
                    .append(" kcal (Calorie intake per day) <br/>");

            result.append("This range of daily calories will enable you to gain 0.5-1.0 kg per week.<br/>");

            return result.toString();

        } else if (bmi >= 18.5 && bmi < 25) {
            StringBuilder result2 = new StringBuilder();

            result2.append("Lose weight: ")
                    .append(String.format("%.0f", loseWeightMin))
                    .append(" to ")
                    .append(String.format("%.0f", loseWeightMax))
                    .append(" kcal (Calorie intake per day) <br/>");

            result2.append(
                    "This range of daily calories will enable you to lose 0.5-1.0 kg per week in a healthy and sustainable way. <br/><br/>");

            result2.append("Maintain weight: ")
                    .append(String.format("%.0f", maintainWeightMin))
                    .append(" to ")
                    .append(String.format("%.0f", maintainWeightMax))
                    .append(" kcal (Calorie intake per day) <br/>");

            result2.append("This range of daily calories will enable you to maintain your current weight.<br/><br/>");

            result2.append("Gain weight: ")
                    .append(String.format("%.0f", gainWeightMin))
                    .append(" to ")
                    .append(String.format("%.0f", gainWeightMax))
                    .append(" kcal (Calorie intake per day)<br/>");

            result2.append("This range of daily calories will enable you to gain 0.5-1.0 kg per week.<br/><br/>");

            return result2.toString();

        } else {
            StringBuilder result3 = new StringBuilder();

            result3.append(
                    "Your BMI is 25.0 or above, which falls within the overweight range. Highly recommend you lose more weight to maintain a healthy body.<br/><br/>");
            
            result3.append("Lose weight: ")
                    .append(String.format("%.0f", loseWeightMin))
                    .append(" to ")
                    .append(String.format("%.0f", loseWeightMax))
                    .append(" kcal (Calorie intake per day)<br/>");

            result3.append(
                    "This range of daily calories will enable you to lose 0.5-1.0 kg per week in a healthy and sustainable way.<br/>");

            return result3.toString();
        }
    }
    
    // -------------------------------------------------------------------------------------------------------
    /**
     * Retrieves the help information.
     *
     * @return a String containing helpful information about the available
     * methods and their required inputs.
     */
    @WebMethod(operationName = "getHelp")
    public String getHelp() {
        StringBuilder result = new StringBuilder();

        result.append("For calculateAge:")
                .append("Require input of gender and identification number.");

        result.append("For calculateBMI:")
                .append("Require input of weight(kg) and height(cm).");

        result.append("For calculateBodyFat:")
                .append("Require input of weight(kg), height(cm), age and gender.");

        result.append("For calculateCalorieBurnRate:")
                .append("Require input of weight(kg), height(cm), age, gender and activity level.");

        result.append("For calculateCalorieIntake:")
                .append("Require input of gender, age, height(cm), weight(kg) and activity level.");

        result.append("Gender Options:")
                .append("  - Male")
                .append("  - Female");

        result.append("Identification format:")
                .append(" - 12 digits, YYMMDD-PB-###G")
                .append(" - YYMMDD is the date of birth")
                .append(" - PB is the place of birth")
                .append(" - ### is the generic special number")
                .append(" - G is the gender (odd number for male, even number for female)");

        result.append("Age format:")
                .append(" - Number of years");

        result.append("Height format:")
                .append(" - written in cm");

        result.append("Weight format:")
                .append(" - written in kg");

        result.append("Activity Level Options:")
                .append("  - A: Sedentary (little or no exercise) e.g. office worker")
                .append("  - B: Lightly active (light exercise/sports 1-3 days/week) e.g. teacher")
                .append("  - C: Moderately active (moderate exercise/sports 3-5 days/week) e.g. delivery driver")
                .append("  - D: Very active (hard exercise/sports 6-7 days a week) e.g. construction worker")
                .append("  - E: Extra active (very hard exercise/sports & a physical job) e.g. military/professional dancer");

        return result.toString();
    }

}
